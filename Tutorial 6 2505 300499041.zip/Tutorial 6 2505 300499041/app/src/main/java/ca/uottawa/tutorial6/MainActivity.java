package ca.uottawa.tutorial6;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import ca.uottawa.tutorial6.FeedReaderContract.FeedEntry;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "SQLiteDemo";
    private FeedReaderDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dbHelper = new FeedReaderDbHelper(this);

        // INSERT
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(FeedEntry.COLUMN_NAME_TITLE, "My Title");
        values.put(FeedEntry.COLUMN_NAME_SUBTITLE, "My Subtitle");
        long newRowId = db.insert(FeedEntry.TABLE_NAME, null, values);
        Log.d(TAG, "Inserted row id = " + newRowId);

        // READ
        readAll();

        // UPDATE
        ContentValues upd = new ContentValues();
        upd.put(FeedEntry.COLUMN_NAME_TITLE, "MyNewTitle");
        int updated = db.update(FeedEntry.TABLE_NAME, upd,
                FeedEntry.COLUMN_NAME_TITLE + " LIKE ?", new String[]{"My Title"});
        Log.d(TAG, "Rows updated = " + updated);
        readAll();

        // DELETE

//        int deleted = db.delete(FeedEntry.TABLE_NAME,
//                FeedEntry.COLUMN_NAME_TITLE + " LIKE ?", new String[]{"MyNewTitle"});
//        Log.d(TAG, "Rows deleted = " + deleted);
        readAll();
    }

    private void readAll() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {BaseColumns._ID,
                FeedEntry.COLUMN_NAME_TITLE, FeedEntry.COLUMN_NAME_SUBTITLE};
        Cursor cursor = db.query(FeedEntry.TABLE_NAME, projection,
                null, null, null, null, FeedEntry.COLUMN_NAME_SUBTITLE + " DESC");
        while (cursor.moveToNext()) {
            long id = cursor.getLong(cursor.getColumnIndexOrThrow(BaseColumns._ID));
            String title = cursor.getString(
                    cursor.getColumnIndexOrThrow(FeedEntry.COLUMN_NAME_TITLE));
            Log.d(TAG, "Row " + id + ": " + title);
        }
        cursor.close();
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}