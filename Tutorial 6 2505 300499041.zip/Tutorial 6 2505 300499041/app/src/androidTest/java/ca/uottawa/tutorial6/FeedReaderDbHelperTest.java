package ca.uottawa.tutorial6;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import ca.uottawa.tutorial6.FeedReaderContract.FeedEntry;

@RunWith(AndroidJUnit4.class)
public class FeedReaderDbHelperTest {
    private Context context;
    private FeedReaderDbHelper dbHelper;
    private SQLiteDatabase db;

    @Before
    public void setUp() {
        context = ApplicationProvider.getApplicationContext();
        context.deleteDatabase(FeedReaderDbHelper.DATABASE_NAME); // start clean
        dbHelper = new FeedReaderDbHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    @After
    public void tearDown() {
        dbHelper.close();
        context.deleteDatabase(FeedReaderDbHelper.DATABASE_NAME);
    }

    @Test
    public void insertThenReadBack() {
        ContentValues v = new ContentValues();
        v.put(FeedEntry.COLUMN_NAME_TITLE, "george");
        v.put(FeedEntry.COLUMN_NAME_SUBTITLE, "sub");
        long id = db.insert(FeedEntry.TABLE_NAME, null, v);
        assertNotEquals(-1, id);

        Cursor c = db.query(FeedEntry.TABLE_NAME, null,
                FeedEntry.COLUMN_NAME_TITLE + " = ?", new String[]{"george"},
                null, null, null);
        assertEquals(1, c.getCount());
        c.close();
    }
}